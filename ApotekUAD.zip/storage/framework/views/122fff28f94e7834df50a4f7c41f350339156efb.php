
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5" style="background-color: white; margin-bottom: 10rem">
      <div class="row">
        <div class="col-md-3">
          <div class="card border-bottom-secondary border-bottom-5 mb-3" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title">Stok Obat</h5>
                  <h1 class="fw-bold"><?php echo e($obat->count()); ?></h1>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card border-bottom-danger border-bottom-5 mb-3" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title">Obat Merah</h5>
                  <h1 class="fw-bold"><?php echo e(App\Models\Obat::get(['kategori'])->where('kategori', 'Obat Merah')->count()); ?></h1>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card border-bottom-primary border-bottom-5 mb-3" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title">Obat Biru</h5>
                  <h1 class="fw-bold"><?php echo e(App\Models\Obat::get(['kategori'])->where('kategori', 'Obat Kuning')->count()); ?></h1>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card border-bottom-success border-bottom-5 mb-3" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-8">
                <div class="card-body">
                  <h5 class="card-title">Obat Hijau</h5>
                  <h1 class="fw-bold"><?php echo e(App\Models\Obat::get(['kategori'])->where('kategori', 'Obat Hijau')->count()); ?></h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <button type="button" class="btn btn-primary mb-5" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Tambah obat
      </button>
      <?php echo $__env->make('includes.modal_tambah_obat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table id="tabel_obat" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Obat</th>
                <th>Kategori Obat</th>
                <th>Harga Obat (Rp)</th>
                <th>Stok Obat</th>
                <th>Foto Obat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataObat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($dataObat->nama); ?></td>
                <td><?php echo e($dataObat->kategori); ?></td>
                <td><?php echo e(number_format($dataObat->harga)); ?></td>
                <td><?php echo e($dataObat->stok); ?></td>
                <td><img src="<?php echo e($dataObat->foto); ?>" alt="" width="100px"></td>
                <td>
                  <div class="row">
                    <div class="col-sm-6">
                      <a href="" class="btn btn-warning btn-block text-white" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($dataObat->id); ?>">
                        <i class="bi bi-pen-fill"></i>
                      </a>
                      <?php echo $__env->make('includes.modal_edit_obat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="col-sm-6">
                     <form action="<?php echo e(route('delete-obat', ['id'=>$dataObat->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger btn-block text-white" onclick="return confirm('Anda yakin akan menghapus data ini?')"><i class="bi bi-trash-fill"></i></button>
                     </form>
                    </div>
                  </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Developments\Laravel\ApotekUAD\resources\views/admin/index.blade.php ENDPATH**/ ?>