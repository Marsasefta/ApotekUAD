
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5" style="background-color: white; margin-bottom: 10rem">
      <button type="button" class="btn btn-primary mb-5" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Tambah obat
      </button>
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('add-obat')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="modal-body">
                <div class="mb-3">
                  <label for="nama" class="form-label">Nama Produk</label>
                  <input class="form-control" id="nama" name="nama">
                </div>
                <div class="mb-3">
                  <label for="deskripsi" class="form-label">Deskripsi Produk</label>
                  <textarea class="form-control" id="deskripsi" rows="3" name="deskripsi"></textarea>
                </div>
                <div class="mb-3">
                  <label for="kategori" class="form-label">Kategori Produk</label>
                  <input class="form-control" id="kategori" name="kategori">
                </div>
                <div class="mb-3">
                  <label for="harga" class="form-label">Harga Produk</label>
                  <input class="form-control" id="harga" name="harga">
                </div>
                <div class="mb-3">
                  <label for="stok" class="form-label">Stok Produk</label>
                  <input class="form-control" id="stok" name="stok">
                </div>
                <div class="mb-3">
                  <label for="foto" class="form-label">Foto Produk</label>
                  <input class="form-control" id="foto" name="foto">
                </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    <table id="tabel_obat" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Obat</th>
                <th>Deskripsi Obat</th>
                <th>Kategori Obat</th>
                <th>Harga Obat</th>
                <th>Stok Obat</th>
                <th>Foto Obat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataObat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($dataObat->nama); ?></td>
                <td><?php echo e($dataObat->deskripsi); ?></td>
                <td><?php echo e($dataObat->kategori); ?></td>
                <td><?php echo e($dataObat->harga); ?></td>
                <td><?php echo e($dataObat->stok); ?></td>
                <td><img src="<?php echo e($dataObat->foto); ?>" alt="" width="100px"></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>Belum ada data</h1>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Development\Laravel\ApotekUAD\resources\views/admin/index.blade.php ENDPATH**/ ?>