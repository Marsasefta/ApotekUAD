

<?php $__env->startSection('content'); ?>

<div class="container" style="display: flex; flex-direction: column; justify-content: center; align-items: center">
    <p><span class="text-primary"><a href="<?php echo e(route('home')); ?>">Home</a></span> / <?php echo e($obatKategori->kategori); ?> / <?php echo e($obatKategori->nama); ?></p>
    <div class="row">
        <div class="col-md-7 mr-5">
            <h3 class="fw-bold"><?php echo e($obatKategori->nama); ?></h3>
            <h1 class="fw-bold">Rp. <?php echo e(number_format($obatKategori->harga)); ?>, 00</h1>
            <h5 class="fw-bold mt-3">Kategori</h5>
            <h5 class="text-danger"><?php echo e($obatKategori->kategori); ?></h5>
            <img src="<?php echo e($obatKategori->foto); ?>" alt="" class="img-fluid rounded shadow-sm">
            <h5 class="fw-bold mt-5">Deskripsi</h5>
            <p><?php echo e($obatKategori->deskripsi); ?></p>
            <div class="row">
                <div class="mt-1">
                    <button class="btn btn-primary btn-block">Tambah Ke Keranjang</button>
                </div>
            </div>
        </div>
        <div class="col-md-4 bg-white shadow-sm rounded py-3">
            <h5>Produk Serupa</h5>
            <?php $__currentLoopData = $obat->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($item->foto); ?>" alt="" class="img-fluid rounded shadow-sm" style="max-width: 13rem">
                <p class="fw-bold"><?php echo e($item->nama); ?></p>
                <h5 class="fw-bold">Rp. <?php echo e(number_format($item->harga)); ?>, 00</h5>
                <p class="text-danger"><?php echo e($item->kategori); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Developments\Laravel\ApotekUAD\resources\views/detail_obat.blade.php ENDPATH**/ ?>