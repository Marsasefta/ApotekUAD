<div class="modal fade" id="edit<?php echo e($dataObat->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit <?php echo e($dataObat->nama); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="/dashboard/<?php echo e($dataObat->id); ?>/edit" method="post">
        <div class="modal-body">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="modal-body">
              <div class="mb-3">
                <label for="nama" class="form-label">Nama Produk</label>
                <input class="form-control" id="nama" name="nama" value="<?php echo e($dataObat->nama); ?>">
              </div>
              <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Produk</label>
                <input class="form-control" id="deskripsi" rows="3" name="deskripsi" value="<?php echo e($dataObat->deskripsi); ?>"></input>
              </div>
              <div class="mb-3">
                <label for="kategori" class="form-label">Kategori Produk</label>
                <select class="form-select" id="kategori" name="kategori">
                  <option selected value="<?php echo e($dataObat->kategori); ?>"><?php echo e($dataObat->kategori); ?></option>
                  <option value="Obat Merah">Obat Merah</option>
                  <option value="Obat Kuning">Obat Kuning</option>
                  <option value="Obat Hijau">Obat Hijau</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="harga" class="form-label">Harga Produk</label>
                <input class="form-control" id="harga" name="harga" value="<?php echo e($dataObat->harga); ?>">
              </div>
              <div class="mb-3">
                <label for="stok" class="form-label">Stok Produk</label>
                <input class="form-control" id="stok" name="stok" value="<?php echo e($dataObat->stok); ?>">
              </div>
              <div class="mb-3">
                <label for="foto" class="form-label">Foto Produk</label>
                <img src="<?php echo e($dataObat->foto); ?>" alt="" width="300px" height="300px">
                <input class="form-control" id="foto" name="foto" value="<?php echo e($dataObat->foto); ?>">
                
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div><?php /**PATH F:\Developments\Laravel\ApotekUAD\resources\views/includes/modal_edit_obat.blade.php ENDPATH**/ ?>